<?php 
/*session_start();
include ('Chat.php');
$chat = new Chat();
$chat->updateUserOnline($_SESSION['user_id'], 0);
$_SESSION['username'] = "";
$_SESSION['user_id']  = "";
$_SESSION['login_details_id']= "";
header("Location:index.php");*/
?>
<?php
header("Location:../../includes/logout.php");
?>






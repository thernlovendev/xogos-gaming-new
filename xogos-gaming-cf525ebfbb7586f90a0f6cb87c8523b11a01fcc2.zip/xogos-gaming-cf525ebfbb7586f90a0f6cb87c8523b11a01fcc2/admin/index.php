<?php include "includes/header.php" ?>
<?php include "includes/sidebar.php" ?>
<?php include "includes/navbar.php" ?>
  
    
      <!-- End Navbar -->
      <div class="content">
      <div class="row">
      <?php include "includes/coins.php" ?>

      <?php include "includes/performance.php" ?>
      <div class="row">
      
      <?php include "includes/friends_online.php" ?>

      <?php include "includes/top_players.php" ?>

      <?php include "includes/top_games.php" ?>
          
        </div>
      </div>
      <?php include "includes/footer.php" ?>
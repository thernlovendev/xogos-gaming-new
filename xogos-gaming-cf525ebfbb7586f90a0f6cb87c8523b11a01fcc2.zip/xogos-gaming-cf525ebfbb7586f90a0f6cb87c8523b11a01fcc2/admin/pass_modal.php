<!-- Modal -->
<div class="modal fade" id="passModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="passModal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="passModal">Password weak</h5>
      </div>
      <div class="modal-body">
        <p>Password must include, 8 letters, uppercase and lowercase, numbers and special characters </p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<?php 

  header("Location: register_kid.php");

?>